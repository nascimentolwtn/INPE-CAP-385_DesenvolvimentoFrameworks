package annotations.tarefa1;

public class Metadados {
	
	@Logging @OptimizeExecution
	public void metodoA(){
		
	}
}
