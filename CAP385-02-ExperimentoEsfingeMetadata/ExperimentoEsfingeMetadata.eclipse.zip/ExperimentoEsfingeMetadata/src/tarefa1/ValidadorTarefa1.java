package tarefa1;

public class ValidadorTarefa1 {
	
	public boolean validarAnotacoesNaClasse(Class<?> clazz) {
		try {				
			return true;
		} catch (Exception e) {
			return false;
		}							
	}

}
