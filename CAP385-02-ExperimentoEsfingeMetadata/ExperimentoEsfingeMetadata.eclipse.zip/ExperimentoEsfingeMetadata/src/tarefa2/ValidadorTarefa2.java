package tarefa2;

public class ValidadorTarefa2 {
	
	public boolean validarAnotacoesNaClasse(Class<?> clazz) {
		try {	
			return true;
		} catch (Exception e) {
			return false;
		}							
	}

}
